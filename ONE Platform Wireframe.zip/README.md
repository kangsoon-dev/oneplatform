
  # ONE Platform Wireframe

  This is a code bundle for ONE Platform Wireframe. The original project is available at https://www.figma.com/design/CyWgphYFMjfiEMEaQ1VN0o/ONE-Platform-Wireframe.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  